package com.mjc813.cinema_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
