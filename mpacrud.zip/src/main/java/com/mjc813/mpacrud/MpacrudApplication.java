package com.mjc813.mpacrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MpacrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(MpacrudApplication.class, args);
    }

}
