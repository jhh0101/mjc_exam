package com.mjc813.coffee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeeApplicationTests {

    @Test
    void contextLoads() {
    }

}
